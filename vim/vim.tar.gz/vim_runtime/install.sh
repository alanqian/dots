if [ "$1" == "" ]; then
  echo ""
  echo "Usage to install amix's vimrc:"
  echo "   sh .vim_runtime/install.sh <system>"
  echo "      - where <system> can be 'mac', 'linux' or 'windows'"
  exit 1
fi
echo '
fun! MySys()
   return "$1"
endfun

set runtimepath=~/.vim_runtime,~/.vim_runtime/after,\$VIMRUNTIME
source ~/dotfiles/vim/bundle.vim
source ~/dotfiles/vim/_vimrc
helptags ~/.vim_runtime/doc' > ~/.vimrc
mkdir ~/tmp/undodir
echo "Installed VIM CONFIGURATION successfully! Enjoy :)"

